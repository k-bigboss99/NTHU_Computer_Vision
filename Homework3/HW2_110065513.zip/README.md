All the functions are in corresponding .py file
for problem 1
    python HW2-1.py
for problem 2
    python HW2-2.py    